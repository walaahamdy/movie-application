package com.example.dell.movieapptry;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by dell on 26/01/2016.
 */
public class DBHelper extends SQLiteOpenHelper{

     public static final String DBNAME = "MovieDB.db";
     public static final int VERSION = 7;

    private static final String TableName = "movie";

    public static final String ID = "_id";
    public static final String MovieID = "MovieId";
    public static final String PosterPath = "MoviePoster";
    public static final String Title = "MovieTitle";
    public static final String  Date= "MovieReleaseDate";
    public static final String VoteAverage = "MovieVoteAverage";
    public static final String Overview = "MovieOverview";





    public DBHelper(Context context) {
        super(context, DBNAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String query ="CREATE TABLE IF NOT EXISTS "+ TableName +
                "(" + ID +" INTEGER PRIMARY KEY AUTOINCREMENT ," +MovieID+ " TEXT ,"+ PosterPath +" TEXT,"+
                Title +" TEXT," + Date + " TEXT,"+ VoteAverage + " TEXT," +Overview + " TEXT"
                + ")";
                 db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TableName);
        onCreate(db);
    }


    public long Insert(String MovieId,String MoviePoster ,String MovieTitle, String MovieReleaseDate,String  MovieVoteAverage,String MovieOverview){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(MovieID,MovieId);
        values.put(PosterPath,MoviePoster);
        values.put(Title,MovieTitle);
        values.put(Date,MovieReleaseDate);
        values.put(VoteAverage, MovieVoteAverage);
        values.put(Overview, MovieOverview);
       return db.insert(TableName, null ,values);
    }

    public boolean Delete(String MovieId )
                {
                    SQLiteDatabase db = this.getWritableDatabase();
                    return db.delete(TableName, MovieID + "=" + MovieId, null) > 0;
              }

    public Cursor getALLRecords(){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("SELECT * FROM " + TableName, null);
        return res;
    }

    public boolean MovieExsit(String MovieId) {
        SQLiteDatabase db = getWritableDatabase();
        String selectString = "SELECT * FROM " +TableName
                + " WHERE " +MovieID + " =? ";
        Cursor cursor = db.rawQuery(selectString, new String[]{MovieId});

        boolean MovieExsit= false;
        if(cursor.moveToFirst()){
            MovieExsit = true;
           // cursor.close();
        }
       // db.close();
        return MovieExsit;
    }

}
