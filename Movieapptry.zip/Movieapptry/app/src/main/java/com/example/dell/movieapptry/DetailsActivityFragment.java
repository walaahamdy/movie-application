package com.example.dell.movieapptry;
import android.os.AsyncTask;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

/**
 * A placeholder fragment containing a simple view
 */
public class DetailsActivityFragment extends Fragment {
    ArrayList<ReviewsTrailers>TrailerReviewList;
    ListView lv;
    ReviewTraileradapter tReviewTraileradapter;
    movie movie = new movie();

    public DetailsActivityFragment() {
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View rootview = inflater.inflate(R.layout.fragment_details, container, false);
        Bundle arguments = getArguments();
        if (arguments != null) {
            movie.setPoster_path(arguments.getString("poster_path"));
            movie.setOriginal_title(arguments.getString("original_title"));
            movie.setRelease_date(arguments.getString("release_date"));
            movie.setVote_average(arguments.getString("vote_average"));
            movie.setOverview(arguments.getString("overview"));
            movie.setId(arguments.getString("id"));


            TrailerReviewList = new ArrayList<>();
            tReviewTraileradapter = new ReviewTraileradapter(getContext(), TrailerReviewList);
            lv = (ListView) rootview.findViewById(R.id.ListTrailerReview);
            View header = inflater.inflate(R.layout.header, null, false);
            ImageView imageView = (ImageView) header.findViewById(R.id.Poster_image);
            String poster = "http://image.tmdb.org/t/p/w185/" + movie.getPoster_path();
            Picasso.with(getActivity()).load(poster).into(imageView);
            TextView title = (TextView) header.findViewById(R.id.movieName);
            TextView date = (TextView) header.findViewById(R.id.movieYear);
            TextView rate = (TextView) header.findViewById(R.id.vote_average);
            TextView Overview = (TextView) header.findViewById(R.id.movieoverview);

            title.setText(movie.getOriginal_title());
            date.setText(movie.getRelease_date());
            rate.setText(movie.getVote_average());
            Overview.setText(movie.getOverview());
            lv.addHeaderView(header);

            ImageButton favorits = (ImageButton) header.findViewById(R.id.imageButton);
            favorits.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    DBHelper moviedb = new DBHelper(getContext());
                     if(moviedb.MovieExsit(movie.getId())) {
                         moviedb.Delete(movie.getId());
                     }
                         long result = moviedb.Insert(movie.getId(), movie.getPoster_path(), movie.getOriginal_title(), movie.getRelease_date(), movie.getVote_average(), movie.getOverview());
                         Toast.makeText(getContext(), "data inserted successfully" + result, Toast.LENGTH_SHORT).show();

                }
            });
            new trailertask().execute("http://api.themoviedb.org/3/movie/" + movie.getId() + "/videos?api_key=912664a49b2f49e8cddc86e5d523ea5e");

        }
        return rootview;
    }

    public class trailertask extends AsyncTask<String,String, ArrayList<ReviewsTrailers> > {

        @Override
        protected  ArrayList<ReviewsTrailers> doInBackground(String... params) {
            HttpURLConnection urlConnection = null;
            BufferedReader reader = null;

            try{
                URL url = new URL(params[0]);
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.connect();
                InputStream inputStream = urlConnection.getInputStream();
                reader = new BufferedReader(new InputStreamReader(inputStream));
                StringBuffer buffer = new StringBuffer();
                String line = "";
                while ((line = reader.readLine()) != null) {

                    buffer.append(line);
                }
                String finaljson = buffer.toString();
                JSONObject response = new JSONObject(finaljson);
                JSONArray results = response.optJSONArray("results");
                for (int i = 0; i < results.length(); i++) {
                    JSONObject finalobject = results.getJSONObject(i);
                    ReviewsTrailers trailers =new ReviewsTrailers();
                    String name = finalobject.getString("name");
                    trailers.setName(name);
                    String id = finalobject.getString("id");
                    trailers.setId(id);
                    String key = finalobject.getString("key");
                    trailers.setKey(key);
                    String type ="trailer";
                    trailers.setType(type);
                    TrailerReviewList.add(trailers);
                }
                return TrailerReviewList;

            }catch (MalformedURLException e){
                e.printStackTrace();
            }
            catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e1) {
                e1.printStackTrace();
            }
            finally{
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (final IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            return null;
        }
        @Override
        protected void onPostExecute(ArrayList<ReviewsTrailers> TrailerReviewList) {
            super.onPostExecute(TrailerReviewList);
            new reviewstask().execute("http://api.themoviedb.org/3/movie/"+movie.getId()+"/reviews?api_key=912664a49b2f49e8cddc86e5d523ea5e");
        }
    }
    public class reviewstask extends AsyncTask<String,String,ArrayList<ReviewsTrailers>  > {

        @Override
        protected ArrayList<ReviewsTrailers> doInBackground(String... params) {
            HttpURLConnection urlConnection = null;
            BufferedReader reader = null;

            try {
                URL url = new URL(params[0]);
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.connect();
                InputStream inputStream = urlConnection.getInputStream();
                reader = new BufferedReader(new InputStreamReader(inputStream));
                StringBuffer buffer = new StringBuffer();
                String line = "";
                while ((line = reader.readLine()) != null) {

                    buffer.append(line);
                }
                String finaljson = buffer.toString();
                JSONObject response = new JSONObject(finaljson);
                JSONArray results = response.optJSONArray("results");
                for (int i = 0; i < results.length(); i++) {
                    JSONObject finalobject = results.getJSONObject(i);
                    ReviewsTrailers review = new ReviewsTrailers();
                    String name = finalobject.getString("author");
                    review.setName(name);
                    String content = finalobject.getString("content");
                    review.setContent(content);
                    String reviewsurl = finalobject.getString("url");
                    review.setUrl(reviewsurl);
                    String type = "reviews";
                    review.setType(type);
                    TrailerReviewList.add(review);

                }
                return TrailerReviewList;

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e1) {
                e1.printStackTrace();
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (final IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(ArrayList<ReviewsTrailers> TrailerReviewList) {
            super.onPostExecute(TrailerReviewList);
            lv.setAdapter(tReviewTraileradapter);
            tReviewTraileradapter.notifyDataSetChanged();
        }


    }
    }




