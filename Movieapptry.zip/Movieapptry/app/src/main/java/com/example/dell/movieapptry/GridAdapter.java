package com.example.dell.movieapptry;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by dell on 29/12/2015.
 */


class GridAdapter extends BaseAdapter {

    ArrayList<movie> MovieList ;
    Context context;
    GridAdapter(Context context,ArrayList<movie> movie){
        this.context=context;
        this.MovieList=movie;

    }

    @Override
    public int getCount() {
        return MovieList.size();
    }

    @Override
    public Object getItem(int position) {
        return MovieList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override

    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater= (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if(convertView==null){
            convertView=inflater.inflate(R.layout.movieview,parent,false);
        }
        ImageView imageView = (ImageView) convertView.findViewById(R.id.movie_image);
        movie mov= MovieList.get(position);
        Picasso.with(context).load(mov.getPoster_path()).into(imageView);
        return convertView;
    }
}