package com.example.dell.movieapptry;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;



public class MainActivity extends AppCompatActivity implements MainActivityFragment.Callback  {

    private boolean mTwoPane;
    private final String DETAILSActivityFRAGMENT_TAG = "DFTAG";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
         setContentView(R.layout.activity_main);
         if (findViewById(R.id.fragment_details_container) != null){
             mTwoPane = true;

             if (savedInstanceState == null) {
                 getSupportFragmentManager().beginTransaction()
                         .replace(R.id.fragment_details_container, new DetailsActivityFragment(),DETAILSActivityFRAGMENT_TAG )
                         .commit();
             }
         } else {
             mTwoPane = false;
         }
         }


    @Override
    public void onItemSelected(movie movie) {
       if(mTwoPane){
           Bundle args = new Bundle();
           args.putString("poster_path",movie.getPoster_path());
           args.putString("original_title",movie.getOriginal_title());
           args.putString("release_date",movie.getRelease_date());
           args.putString("vote_average",movie.getVote_average());
           args.putString("overview",movie.getOverview());
           args.putString("id",movie.getId());

           DetailsActivityFragment fragment = new DetailsActivityFragment();
           fragment.setArguments(args);

           getSupportFragmentManager().beginTransaction()
                   .replace(R.id.fragment_details_container, fragment,DETAILSActivityFRAGMENT_TAG)
                   .commit();
       } else {
           Intent i = new Intent(this,DetailsActivity.class);
            i.putExtra("poster_path",movie.getPoster_path());
            i.putExtra("original_title",movie.getOriginal_title());
            i.putExtra("release_date",movie.getRelease_date());
            i.putExtra("vote_average",movie.getVote_average());
            i.putExtra("overview",movie.getOverview());
            i.putExtra("id",movie.getId());
            startActivity(i);
       }
       }
    }

