package com.example.dell.movieapptry;
import android.database.Cursor;
import android.os.AsyncTask;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;


/**
 * A placeholder fragment containing a simple view.
 */
public class MainActivityFragment extends Fragment {
    private static final String LOG_TAG = MainActivityFragment.class.getSimpleName();
  private int mPosition = ListView.INVALID_POSITION;
   private static final String SELECTED_KEY = "selected_position";
    ArrayList<movie> MovieList;
    GridView gv;
    GridAdapter mGridAdapter;
    String MostPopulars="http://api.themoviedb.org/3/discover/movie?sort_by=popularity.desc&api_key=912664a49b2f49e8cddc86e5d523ea5e";
    String Highest_Rated ="http://api.themoviedb.org/3/discover/movie?sort_by=vote_average.desc&api_key=912664a49b2f49e8cddc86e5d523ea5e";
    String Base_URL ="http://api.themoviedb.org/3/discover/movie?&api_key=912664a49b2f49e8cddc86e5d523ea5e";


    public MainActivityFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setHasOptionsMenu(true);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_main, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        switch (id){
            case R.id.action_MostPopular:
                new jsontask().execute(MostPopulars);
                break;
            case R.id.action_HighestRated:
                new jsontask().execute(Highest_Rated);
                break;
            case R.id.action_favorits:
                selectfavorits();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_main, container, false);
        MovieList = new ArrayList<>();
        gv = (GridView) rootView.findViewById(R.id.gridView);
        mGridAdapter=new GridAdapter(getContext(),MovieList);
        gv.setOnItemClickListener( new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                movie movies = (movie) mGridAdapter.getItem(position);

                if (movies != null) {
                    ((Callback) getActivity())
                            .onItemSelected(movies);
                }
                mPosition = position;
            }

        });

                     new jsontask().execute(Base_URL);

                    if (savedInstanceState != null && savedInstanceState.containsKey(SELECTED_KEY)) {
                                      mPosition = savedInstanceState.getInt(SELECTED_KEY);
                  }




        return rootView;
    }

    @Override
       public void onSaveInstanceState(Bundle outState) {
        if (mPosition != ListView.INVALID_POSITION) {
            outState.putInt(SELECTED_KEY, mPosition);
        }
                super.onSaveInstanceState(outState);
            }



    public interface Callback {
        public void onItemSelected(movie movie);
    }


    public class jsontask extends AsyncTask<String,String, ArrayList<movie> > {

        @Override
        protected  ArrayList<movie> doInBackground(String... params) {
            HttpURLConnection urlConnection = null;
            BufferedReader reader = null;

            try{
                URL url = new URL(params[0]);
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.connect();
                InputStream inputStream = urlConnection.getInputStream();
                reader = new BufferedReader(new InputStreamReader(inputStream));
                StringBuffer buffer = new StringBuffer();
                String line = "";
                while ((line = reader.readLine()) != null) {

                    buffer.append(line);
                }
                String finaljson = buffer.toString();
                JSONObject response = new JSONObject(finaljson);
                JSONArray results = response.optJSONArray("results");
                MovieList.clear();
                for (int i = 0; i < results.length(); i++) {
                    JSONObject finalobject = results.getJSONObject(i);
                    movie movies = new movie();
                    String image = finalobject.getString("poster_path");
                    movies.setPoster_path("http://image.tmdb.org/t/p/w185/"+image);
                    String title= finalobject.getString("original_title");
                    movies.setOriginal_title(title);
                    String date= finalobject.getString("release_date");
                    movies.setRelease_date(date);
                    String rate=finalobject.getString("vote_average");
                    movies.setVote_average(rate);
                    String overview = finalobject.getString("overview");
                    movies.setOverview(overview);
                    String id = finalobject.getString("id");
                    movies.setId(id);
                    MovieList.add(movies);

                }
                return MovieList;

            }catch (MalformedURLException e){
                e.printStackTrace();
            }
            catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e1) {
                e1.printStackTrace();
            }
            finally{
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (final IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            return null;
        }
        @Override
        protected void onPostExecute( ArrayList<movie> MovieList) {
            super.onPostExecute(MovieList);
                gv.setAdapter(mGridAdapter);

            if(mPosition != ListView.INVALID_POSITION){
                gv.smoothScrollToPosition(mPosition);
            }
            mGridAdapter.notifyDataSetChanged();

        }
    }

    public void selectfavorits(){
        ArrayList<movie> arrayList = new ArrayList<movie>();
        DBHelper db = new DBHelper(getContext());
        Cursor res = db.getALLRecords();
        res.moveToFirst();
        while(res.isAfterLast()== false){
            movie movie =new movie();
            movie.setId(res.getString(res.getColumnIndex(db.MovieID)));
            movie.setPoster_path(res.getString(res.getColumnIndex(db.PosterPath)));
            movie.setOriginal_title(res.getString(res.getColumnIndex(db.Title)));
            movie.setRelease_date(res.getString(res.getColumnIndex(db.Date)));
            movie.setVote_average(res.getString(res.getColumnIndex(db.VoteAverage)));
            movie.setOverview(res.getString(res.getColumnIndex(db.Overview)));
            arrayList.add(movie);
            res.moveToNext();
        }
        mGridAdapter=new GridAdapter(getContext(),arrayList);
        gv.setAdapter(mGridAdapter);
        if(mPosition != ListView.INVALID_POSITION){
            gv.smoothScrollToPosition(mPosition);
        }
    }

}


