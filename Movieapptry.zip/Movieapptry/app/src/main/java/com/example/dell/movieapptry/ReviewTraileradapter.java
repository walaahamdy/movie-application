package com.example.dell.movieapptry;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by dell on 16/01/2016.
 */
public class ReviewTraileradapter extends BaseAdapter {
    ArrayList<ReviewsTrailers>TrailerReviewList;
    Context context;
    ReviewTraileradapter(Context context, ArrayList<ReviewsTrailers> TrailerReview){
        this.context=context;
        this.TrailerReviewList=TrailerReview;

    }

    @Override
    public int getCount() {
        return TrailerReviewList.size();
    }

    @Override
    public Object getItem(int position) {
        return TrailerReviewList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater= (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        final ReviewsTrailers reviewstrailers = TrailerReviewList.get(position);
        String type = reviewstrailers.getType();
        if (type =="trailer"){
            convertView=inflater.inflate(R.layout.trailers,parent,false);
            TextView name = (TextView)convertView.findViewById(R.id.trailerName);
            name.setText(reviewstrailers.getName());

            name.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=" + reviewstrailers.getKey()));
                    context.startActivity(i);
                }
            });
        }
        if(type == "reviews"){
            convertView =inflater.inflate(R.layout.reviews,parent,false);
            TextView url = (TextView)convertView.findViewById(R.id.reviewsurl);
            url.setText(reviewstrailers.getUrl());
            TextView authorname=(TextView)convertView.findViewById(R.id.AuthorName);
            authorname.setText(reviewstrailers.getName());
            TextView content =(TextView)convertView.findViewById(R.id.content);
            content.setText(reviewstrailers.getContent());
        }
        return convertView;
    }
}
